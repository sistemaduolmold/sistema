const storageKey = "duomold-demo-v3";

const demoData = {
  activeAccount: "user:user-admin",
  companies: [
    { id: "empresa-1", name: "Metal Norte, Lda.", vat: "PT509876321", email: "geral@metalnorte.pt", phone: "+351 255 100 200", city: "Porto", sector: "Metalomecanica", address: "Rua Industrial 120, Porto", notes: "Cliente ativo para acompanhamento de molde." },
    { id: "empresa-2", name: "Plastiform Moldes", vat: "PT514223987", email: "info@plastiform.pt", phone: "+351 244 300 550", city: "Leiria", sector: "Moldes", address: "Zona Industrial, Leiria", notes: "Prospeccao iniciada este mes." }
  ],
  clients: [
    { id: "client-ana", name: "Ana Martins", companyId: "empresa-1", email: "ana@metalnorte.pt", password: "cliente123", phone: "+351 912 345 678", status: "Ativo", owner: "Admin", role: "Compras", notes: "Cliente principal para acompanhamento semanal." },
    { id: "client-carlos", name: "Carlos Silva", companyId: "empresa-2", email: "carlos@plastiform.pt", password: "cliente123", phone: "+351 934 567 210", status: "Prospecto", owner: "Admin", role: "Direcao tecnica", notes: "Aguardar validacao dos dados da empresa." }
  ],
  users: [
    { id: "user-admin", name: "Administrador", email: "admin@empresa.pt", password: "admin123", phone: "+351 900 000 001", role: "Admin", department: "Direcao", position: "Administrador", status: "Ativo" },
    { id: "user-rh", name: "Recursos Humanos", email: "rh@empresa.pt", password: "rh123", phone: "+351 900 000 002", role: "RH", department: "Recursos Humanos", position: "Gestor RH", status: "Ativo" },
    { id: "user-funcionario", name: "Joao Ferreira", email: "joao@empresa.pt", password: "funcionario123", phone: "+351 900 000 003", role: "Funcionario", department: "Producao", position: "Tecnico", status: "Ativo" }
  ],
  orders: [
    { id: "order-1", clientId: "client-ana", reference: "OS-2026-001", title: "Planeamento de molde", description: "Molde técnico para nova encomenda.", status: "Em produção", progress: "45", dueDate: "2026-06-15", weeklyUpdate: "Molde em fase de planeamento e validação técnica.", tasks: "Revisão técnica; preparação MOD 54; preparação MOD 55." },
    { id: "order-2", clientId: "client-carlos", reference: "OS-2026-002", title: "Ajuste de cavidade", description: "Revisão e ajuste de molde existente.", status: "Em análise", progress: "20", dueDate: "2026-06-28", weeklyUpdate: "Equipa técnica a rever ficheiros enviados.", tasks: "Análise dimensional; contacto com cliente." }
  ],
  vacations: [
    { id: "vac-1", userId: "user-funcionario", startDate: "2026-07-01", endDate: "2026-07-15", days: "15", origin: "Admin/RH", status: "Aprovado", notes: "Periodo definido pela administracao.", decidedBy: "Administrador" },
    { id: "vac-2", userId: "user-funcionario", startDate: "2026-08-10", endDate: "2026-08-14", days: "5", origin: "Funcionario", status: "Pendente", notes: "Pedido do funcionario.", decidedBy: "" }
  ],
  absences: [
    { id: "abs-1", userId: "user-funcionario", date: "2026-05-20", type: "Justificada", status: "Pendente", reason: "Consulta medica", decidedBy: "" }
  ]
};

const scheduleOperations = [
  ["Mapa de Inputs/Outputs", "Input / Output Map", ""],
  ["Preliminar do Molde", "Mold Preliminary Drawing", "DM"],
  ["AMFE/1a Revisao Projecto", "FMEA/Project Revision", "/DM"],
  ["Projecto 3D Molde", "3D Molde Project", "DM"],
  ["Aprovacao do Projecto", "Project aproval", "DM"],
  ["Requisicao de Materiais", "Raw material invoice", "DM"],
  ["Fresagem", "Milling", "DM"],
  ["Refrigeracao", "Cooling", "DM"],
  ["Maquinacao Placas", "Mould Base Machining", "DM"],
  ["Projecto Electrodos", "Electrodes Project", "DM"],
  ["Maquinacao de Electrodos", "Electrodes Machining", "DM"],
  ["Erosao", "Spark Erosion", "DM"],
  ["Polimento", "Polishing", "DM"],
  ["Rectificacao", "Grinding", "DM"],
  ["Ajuste e montagem", "Adjustment / Assembling", "DM"],
  ["1as Amostras", "1ST Samples", "DM"],
  ["Correccoes", "Corrections", "DM"],
  ["Tratamento Termico", "Heat Treatment", "DM"],
  ["2as Amostras", "2nd Samples", "DM"],
  ["Amostras finais / PPAP", "Final Samples /PPAP", "DM"],
  ["Aprovacao de molde", "Mold approval", ""]
];

const planningStatusOptions = ["Tarefa", "Dividir", "Marco", "Sumario", "Resumo de Projeto", "Tarefa Inativa", "Marco Inativo", "Resumo Inativo", "Tarefa Manual", "Apenas-duracao", "Resumo da Agregacao Manual", "Resumo Manual", "Apenas inicio", "Apenas-conclusao", "Tarefas Externas", "Marco Externo", "Prazo", "Progresso", "Progresso Manual"];

const planningBase = [
  ["Project Duration", "", "", "", "Resumo de Projeto"],
  ["PURCHASE ORDER", "", "", "", "Sumario"],
  ["Purchase Order Receipt", "", "", "", "Tarefa"],
  ["CAD", "", "", "", "Sumario"],
  ["Customer: Delivery Part and TDS", "", "", "", "Tarefa"],
  ["Mold Design: Preliminary Project", "", "", "", "Tarefa"],
  ["Customer Approval: Steels and mold concept", "", "", "", "Tarefa"],
  ["Moldflow study", "", "", "", "Tarefa"],
  ["Mold Design: Semi-Final Project", "", "", "", "Tarefa"],
  ["Customer Approval: Millings", "", "", "", "Tarefa"],
  ["Mold Design: Final Project", "", "", "", "Tarefa"],
  ["Customer Approval: Final Project", "", "", "", "Tarefa"],
  ["STEEL ORDER-RECEIVING", "", "", "", "Sumario"],
  ["Steel Order", "", "", "", "Tarefa"],
  ["Steel Receiving", "", "", "", "Tarefa"],
  ["MOLDBASE/STRUCTURE", "", "", "", "Sumario"],
  ["CNC Milling", "", "", "", "Tarefa"],
  ["Drilling", "", "", "", "Tarefa"],
  ["Grinding", "", "", "", "Tarefa"],
  ["ENGRAVING", "", "", "", "Sumario"],
  ["Core Side", "", "", "", "Sumario"],
  ["Core - 200", "", "", "", "Sumario"],
  ["Milling and Treatment", "", "", "", "Sumario"],
  ["Rough Milling", "", "", "", "Tarefa"],
  ["Pre-Finishing Milling", "", "", "", "Tarefa"],
  ["Heat Treatments", "", "", "", "Tarefa"],
  ["Finishing Milling", "", "", "", "Tarefa"],
  ["Inserts/Slides/Lifters Trimming", "", "", "", "Tarefa"],
  ["Spark Erosion", "", "", "", "Sumario"],
  ["Electrodes Definition", "", "", "", "Tarefa"],
  ["Electrodes Milling", "", "", "", "Tarefa"],
  ["Part Erosion", "", "", "", "Tarefa"],
  ["Polishing", "", "", "", "Sumario"],
  ["Cavity Side", "", "", "", "Sumario"],
  ["Cavity - 100", "", "", "", "Sumario"],
  ["Slides", "", "", "", "Sumario"],
  ["Lifters", "", "", "", "Sumario"],
  ["Inserts", "", "", "", "Sumario"],
  ["INJECTION", "", "", "", "Sumario"],
  ["Hot Runner", "", "", "", "Sumario"],
  ["Hot Runner Order", "", "", "", "Tarefa"],
  ["Mold Designer Approval", "", "", "", "Tarefa"],
  ["Hot Runner Reception", "", "", "", "Tarefa"],
  ["BENCH WORK", "", "", "", "Sumario"],
  ["Core-Cooling circuits tapping/testing", "", "", "", "Tarefa"],
  ["Cavity-Cooling circuits tapping/testing", "", "", "", "Tarefa"],
  ["Ejection Assembly", "", "", "", "Tarefa"],
  ["MOLD FITTING/SPOTTING", "", "", "", "Sumario"],
  ["Injection system assembly", "", "", "", "Tarefa"],
  ["Mold Assembly", "", "", "", "Tarefa"],
  ["Final Polishing", "", "", "", "Tarefa"],
  ["TRYOUT", "", "", "", "Sumario"],
  ["Tryout Date", "", "", "", "Marco"],
  ["Post Tryout Mold Venting", "", "", "", "Tarefa"]
].map(([nome, duracao, inicio, conclusao, status], index) => ({ id: index + 1, nome, duracao, inicio, conclusao, status, extras: [] }));

let state = loadState();
let currentView = "adminPage";
let dialogMode = "client";
let editingId = null;

const views = {
  dashboard: qs("#dashboardView"),
  adminPage: qs("#adminPageView"),
  rhPage: qs("#rhPageView"),
  employeePage: qs("#employeePageView"),
  clients: qs("#clientsView"),
  companies: qs("#companiesView"),
  orders: qs("#ordersView"),
  clientPortal: qs("#clientPortalView"),
  users: qs("#usersView"),
  vacations: qs("#vacationsView"),
  absences: qs("#absencesView")
};

const titles = {
  dashboard: ["Painel", "Visão geral dos clientes e equipa."],
  adminPage: ["Admin", "Painel administrativo da DUOMOLD."],
  rhPage: ["RH", "Gestao de férias, faltas e colaboradores."],
  employeePage: ["Funcionario", "Area pessoal para férias e faltas."],
  clients: ["Clientes / Empresas", "Cadastro unificado de clientes, empresas e acessos."],
  companies: ["Empresas", "Dados basicos das empresas."],
  orders: ["Encomendas", "Pedidos de clientes e acompanhamento semanal."],
  clientPortal: ["Meu pedido", "Acompanhamento das suas encomendas."],
  users: ["Colaboradores", "Utilizadores Admin, RH e Funcionario."],
  vacations: ["Férias", "Marcacao, pedido e validacao de férias."],
  absences: ["Faltas", "Registo e validacao de faltas."]
};

const forms = {
  client: [
    ["name", "Nome do cliente", "text", true],
    ["companyName", "Nome da empresa", "text", true],
    ["vat", "NIF", "text"],
    ["email", "Email de acesso", "email", true],
    ["password", "Senha do cliente", "password", true],
    ["phone", "Telefone", "tel"],
    ["city", "Cidade", "text"],
    ["sector", "Setor", "text"],
    ["status", "Estado", "select:Ativo|Prospecto|Inativo"],
    ["owner", "Responsável", "text"],
    ["role", "Função/Cargo", "text"],
    ["address", "Morada da Empresa", "textarea"],
    ["notes", "Observações", "textarea"]
  ],
  company: [
    ["name", "Nome da empresa", "text", true],
    ["vat", "NIF", "text"],
    ["email", "Email", "email"],
    ["phone", "Telefone", "tel"],
    ["city", "Cidade", "text"],
    ["sector", "Setor", "text"],
    ["address", "Morada", "textarea"],
    ["notes", "Observacoes", "textarea"]
  ],
  order: [
    ["clientId", "Cliente", "client", true],
    ["reference", "Referência/OS", "text", true],
    ["title", "Titulo", "text", true],
    ["status", "Estado", "select:Recebido|Em análise|Em produção|Aguardando cliente|Concluído|Entregue"],
    ["progress", "Progresso (%)", "number", true],
    ["dueDate", "Previsão de entrega", "date"],
    ["description", "Descrição", "textarea"],
    ["weeklyUpdate", "Atualização semanal para o cliente", "textarea"],
    ["tasks", "Tarefas internas", "textarea"]
  ],
  user: [
    ["name", "Nome do colaborador", "text", true],
    ["role", "Perfil", "select:Funcionario|RH|Admin", true],
    ["email", "Email", "email", true],
    ["password", "Senha", "password", true],
    ["phone", "Telefone", "tel"],
    ["department", "Departamento", "text"],
    ["position", "Cargo", "text"],
    ["status", "Estado", "select:Ativo|Inativo"]
  ],
  vacation: [
    ["userId", "Colaborador", "user", true],
    ["origin", "Origem", "select:Admin/RH|Funcionario"],
    ["startDate", "Data inicial", "date", true],
    ["endDate", "Data final", "date", true],
    ["days", "Dias úteis calculados", "number"],
    ["status", "Estado", "select:Pendente|Aprovado|Rejeitado"],
    ["notes", "Observações", "textarea"]
  ],
  absence: [
    ["userId", "Colaborador", "user", true],
    ["date", "Data", "date", true],
    ["type", "Tipo", "select:Justificada|Injustificada|Baixa|Outro"],
    ["compensateVacation", "Compensar com 1 dia de férias", "select:Não|Sim"],
    ["status", "Estado", "select:Pendente|Aprovado|Rejeitado"],
    ["reason", "Motivo", "textarea"]
  ]
};

function qs(selector) {
  return document.querySelector(selector);
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) || "null");
    if (!saved) throw new Error("no state");
    return mergeState(saved);
  } catch {
    const fresh = structuredClone(demoData);
    localStorage.setItem(storageKey, JSON.stringify(fresh));
    return fresh;
  }
}

function mergeState(saved) {
  const merged = structuredClone(demoData);
  Object.assign(merged, saved);
  ["companies", "clients", "users", "orders", "vacations", "absences"].forEach((key) => {
    if (!Array.isArray(merged[key]) || !merged[key].length) merged[key] = structuredClone(demoData[key]);
  });
  merged.orders = merged.orders.map(normalizeOrderText);
  if (!merged.activeAccount) merged.activeAccount = "user:user-admin";
  localStorage.setItem(storageKey, JSON.stringify(merged));
  return merged;
}

function normalizeOrderText(order) {
  const statusMap = {
    "Em producao": "Em produção",
    "Em analise": "Em análise",
    Concluido: "Concluído"
  };
  return {
    ...order,
    status: statusMap[order.status] || order.status
  };
}

function saveState() {
  localStorage.setItem(storageKey, JSON.stringify(state));
  render();
}

function account() {
  const [type, id] = state.activeAccount.split(":");
  return { type, id };
}

function currentUser() {
  const current = account();
  return current.type === "user" ? state.users.find((user) => user.id === current.id) : null;
}

function currentClient() {
  const current = account();
  return current.type === "client" ? state.clients.find((client) => client.id === current.id) : null;
}

function isClient() {
  return account().type === "client";
}

function role() {
  return currentUser()?.role || "Cliente";
}

function allowedViews() {
  if (isClient()) return ["clientPortal"];
  if (role() === "Admin") return ["adminPage", "dashboard", "clients", "orders", "users", "vacations", "absences"];
  if (role() === "RH") return ["rhPage", "users", "vacations", "absences"];
  return ["employeePage", "users", "vacations", "absences"];
}

function defaultView() {
  if (isClient()) return "clientPortal";
  if (role() === "Admin") return "adminPage";
  if (role() === "RH") return "rhPage";
  return "employeePage";
}

function setView(view) {
  currentView = allowedViews().includes(view) ? view : defaultView();
  Object.entries(views).forEach(([name, element]) => element?.classList.toggle("active", name === currentView));
  qsa(".nav-item").forEach((button) => {
    button.hidden = !allowedViews().includes(button.dataset.view);
    button.classList.toggle("active", button.dataset.view === currentView);
  });
  qs("#pageTitle").textContent = titles[currentView][0];
  qs("#pageSubtitle").textContent = titles[currentView][1];
  qs("#newRecordButton").textContent = actionLabel();
  qs("#newRecordButton").hidden = !canCreateHere();
}

function qsa(selector) {
  return [...document.querySelectorAll(selector)];
}

function actionLabel() {
  return {
    adminPage: "Nova encomenda",
    dashboard: "Novo cliente / empresa",
    clients: "Novo cliente / empresa",
    companies: "Nova empresa",
    orders: "Nova encomenda",
    users: "Novo colaborador",
    rhPage: "Adicionar férias",
    employeePage: "Pedir férias",
    vacations: "Adicionar férias",
    absences: "Registar falta"
  }[currentView] || "Novo";
}

function canCreateHere() {
  if (isClient()) return false;
  if (role() === "Admin") return ["adminPage", "dashboard", "clients", "orders", "users", "vacations", "absences"].includes(currentView);
  if (role() === "RH") return ["rhPage", "vacations", "absences"].includes(currentView);
  return ["employeePage", "vacations", "absences"].includes(currentView);
}

function modeFromView() {
  return { adminPage: "order", dashboard: "client", clients: "client", orders: "order", users: "user", rhPage: "vacation", employeePage: "vacation", vacations: "vacation", absences: "absence" }[currentView] || "client";
}

function render() {
  qs("#loginScreen").hidden = true;
  qs("#appShell").hidden = false;
  renderAccountSelector();
  renderDashboard();
  renderRolePages();
  renderClients();
  renderCompanies();
  renderOrders();
  renderClientPortal();
  renderUsers();
  renderVacations();
  renderAbsences();
  setView(currentView);
}

function renderAccountSelector() {
  const options = [
    ...state.users.map((user) => ({ value: `user:${user.id}`, label: `${user.name} - ${user.role}` })),
    ...state.clients.map((client) => ({ value: `client:${client.id}`, label: `${client.name} - Cliente` }))
  ];
  qs("#demoAccountSelect").innerHTML = options.map((option) => `<option value="${option.value}" ${state.activeAccount === option.value ? "selected" : ""}>${esc(option.label)}</option>`).join("");
  qs("#currentSessionName").textContent = isClient() ? `${currentClient()?.name || "Cliente"} - Cliente` : `${currentUser()?.name || "Utilizador"} - ${role()}`;
  qs("#sessionHint").textContent = isClient() ? "Pode acompanhar as suas encomendas" : role() === "Funcionario" ? "Pode pedir férias e registar faltas" : "Pode gerir e validar informacao";
}

function renderDashboard() {
  text("#totalClients", state.clients.length);
  text("#totalCompanies", state.clients.length);
  text("#totalUsers", state.users.length);
  text("#pendingVacations", state.vacations.filter((item) => item.status === "Pendente").length);
  compact("#recentClients", state.clients.slice(0, 4), (client) => ({ title: client.name, meta: `${companyName(client.companyId)} - ${client.email}`, badge: client.status }));
  compact("#pendingVacationList", state.vacations.filter((item) => item.status === "Pendente"), (item) => ({ title: userName(item.userId), meta: `${date(item.startDate)} a ${date(item.endDate)} - ${item.days} dias`, badge: item.origin }));
}

function renderRolePages() {
  const openOrders = state.orders.filter((order) => !["Concluido", "Entregue"].includes(order.status));
  text("#adminOpenOrders", openOrders.length);
  text("#adminClientLogins", state.clients.filter((client) => client.email && client.password).length);
  text("#adminPendingVacations", state.vacations.filter((item) => item.status === "Pendente").length);
  text("#adminPendingAbsences", state.absences.filter((item) => item.status === "Pendente").length);
  compact("#adminOrdersList", openOrders, (order) => ({ title: `${order.reference} - ${clientName(order.clientId)}`, meta: `${order.status} - ${order.progress}%`, badge: date(order.dueDate) }));
  compact("#rhVacationsList", state.vacations.filter((item) => item.status === "Pendente"), (item) => ({ title: userName(item.userId), meta: `${date(item.startDate)} a ${date(item.endDate)}`, badge: `${item.days} dias` }));
  compact("#rhAbsencesList", state.absences.filter((item) => item.status === "Pendente"), (item) => ({ title: userName(item.userId), meta: item.reason || "Sem motivo", badge: item.type }));
  const employeeId = currentUser()?.id || "user-funcionario";
  const vacations = state.vacations.filter((item) => item.userId === employeeId);
  const approved = sum(vacations.filter((item) => item.status === "Aprovado" && item.origin === "Funcionario"));
  const pending = sum(vacations.filter((item) => item.status === "Pendente" && item.origin === "Funcionario"));
  text("#employeeApprovedDays", approved);
  text("#employeePendingDays", pending);
  text("#employeeAvailableDays", Math.max(15 - approved - pending, 0));
  text("#employeePendingAbsences", state.absences.filter((item) => item.userId === employeeId && item.status === "Pendente").length);
  compact("#employeeVacationsList", vacations, (item) => ({ title: `${date(item.startDate)} a ${date(item.endDate)}`, meta: `${item.days} dias - ${item.origin}`, badge: item.status }));
  compact("#employeeAbsencesList", state.absences.filter((item) => item.userId === employeeId), (item) => ({ title: date(item.date), meta: item.reason, badge: item.status }));
}

function renderClients() {
  const query = value("#clientSearch");
  const rows = state.clients.filter((client) => {
    const company = companyForClient(client);
    return search([client.name, client.email, client.phone, client.status, client.role, company.name, company.vat, company.city, company.sector], query);
  });
  table("#clientsTable", rows, (client) => {
    const company = companyForClient(client);
    return `
      <tr>
        <td><strong>${esc(client.name)}</strong><small>${esc(company.name || "Sem empresa")} - ${esc(client.role || "Sem cargo")}</small></td>
        <td>${esc(company.vat || "Sem NIF")}</td>
        <td><strong>${esc(client.email)}</strong><small>${esc(client.phone || company.phone || "Sem telefone")}</small></td>
        <td><strong>${esc(company.city || "Sem cidade")}</strong><small>${esc(company.sector || "Sem setor")}</small></td>
        <td><span class="status ${cls(client.status)}">${esc(client.status)}</span></td>
        <td><div class="row-actions"><button class="row-action" data-edit-client="${client.id}">Editar</button><button class="row-action" data-new-client-order="${client.id}">Nova encomenda</button><button class="row-action delete" data-delete-client="${client.id}">Apagar</button></div></td>
      </tr>`;
  });
}

function renderCompanies() {
  const query = value("#companySearch");
  const rows = state.companies.filter((company) => search([company.name, company.vat, company.email, company.city, company.sector], query));
  table("#companiesTable", rows, (company) => `
    <tr>
      <td><strong>${esc(company.name)}</strong><small>${esc(company.address || "Sem morada")}</small></td>
      <td>${esc(company.vat || "Sem NIF")}</td>
      <td><strong>${esc(company.email || "Sem email")}</strong><small>${esc(company.phone || "Sem telefone")}</small></td>
      <td>${esc(company.city || "Sem cidade")}</td>
      <td>${esc(company.sector || "Sem setor")}</td>
      <td><div class="row-actions"><button class="row-action" data-edit-company="${company.id}">Editar</button><button class="row-action delete" data-delete-company="${company.id}">Apagar</button></div></td>
    </tr>`);
}

function renderOrders() {
  const query = value("#orderSearch");
  const rows = state.orders.filter((order) => search([order.reference, order.title, order.status, clientName(order.clientId), order.weeklyUpdate], query));
  table("#ordersTable", rows, (order) => `
    <tr>
      <td><strong>${esc(order.reference)}</strong><small>${esc(order.title)}</small></td>
      <td>${esc(clientName(order.clientId))}</td>
      <td><span class="status ${cls(order.status)}">${esc(order.status)}</span></td>
      <td><strong>${esc(order.progress)}%</strong><small>Previsão: ${date(order.dueDate)}</small></td>
      <td>${esc(order.weeklyUpdate || "Sem atualização")}</td>
      <td><div class="row-actions"><button class="row-action" data-edit-order="${order.id}">Editar</button><button class="row-action" data-planning-order="${order.id}">Planeamento</button><button class="row-action" data-schedule-order="${order.id}">Cronograma</button><button class="row-action delete" data-delete-order="${order.id}">Apagar</button></div></td>
    </tr>`);
}

function renderClientPortal() {
  const clientId = currentClient()?.id;
  const rows = state.orders.filter((order) => order.clientId === clientId);
  table("#clientOrdersTable", rows, (order) => `
    <tr>
      <td><strong>${esc(order.reference)}</strong><small>${esc(order.title)}</small></td>
      <td><span class="status ${cls(order.status)}">${esc(order.status)}</span></td>
      <td><strong>${esc(order.progress)}%</strong><small>${esc(order.description || "")}</small></td>
      <td>${date(order.dueDate)}</td>
      <td>${esc(order.weeklyUpdate || "Sem atualização semanal")}</td>
      <td><div class="row-actions"><button class="row-action" data-planning-order="${order.id}">Planeamento</button><button class="row-action" data-schedule-order="${order.id}">Cronograma</button></div></td>
    </tr>`);
}

function renderUsers() {
  const query = value("#userSearch");
  const rows = (role() === "Funcionario" ? state.users.filter((user) => user.id === currentUser()?.id) : state.users).filter((user) => search([user.name, user.email, user.role, user.department], query));
  table("#usersTable", rows, (user) => {
    const total = sum(state.vacations.filter((item) => item.userId === user.id && item.status !== "Rejeitado"));
    return `<tr>
      <td><strong>${esc(user.name)}</strong><small>${esc(user.position || "Sem cargo")}</small></td>
      <td><span class="status ${cls(user.role)}">${esc(user.role)}</span></td>
      <td><strong>${esc(user.email)}</strong><small>${esc(user.phone || "Sem telefone")}</small></td>
      <td>${esc(user.department || "Sem departamento")}</td>
      <td><strong>${total}/30 dias</strong><small>Limite anual</small></td>
      <td><div class="row-actions">${role() === "Admin" ? `<button class="row-action" data-edit-user="${user.id}">Editar</button><button class="row-action delete" data-delete-user="${user.id}">Apagar</button>` : ""}</div></td>
    </tr>`;
  });
}

function renderVacations() {
  const query = value("#vacationSearch");
  const rows = state.vacations.filter((item) => role() !== "Funcionario" || item.userId === currentUser()?.id).filter((item) => search([userName(item.userId), item.origin, item.status, item.notes], query));
  table("#vacationsTable", rows, (item) => `
    <tr>
      <td><strong>${esc(userName(item.userId))}</strong><small>${esc(item.notes || "Sem observacoes")}</small></td>
      <td><strong>${date(item.startDate)} a ${date(item.endDate)}</strong><small>Validado por: ${esc(item.decidedBy || "pendente")}</small></td>
      <td>${esc(item.days)}</td>
      <td>${esc(item.origin)}</td>
      <td><span class="status ${cls(item.status)}">${esc(item.status)}</span></td>
      <td><div class="row-actions">${role() !== "Funcionario" ? `<button class="row-action" data-edit-vacation="${item.id}">Editar</button><button class="row-action approve" data-approve-vacation="${item.id}">Aprovar</button><button class="row-action delete" data-reject-vacation="${item.id}">Rejeitar</button>` : ""}</div></td>
    </tr>`);
}

function renderAbsences() {
  const query = value("#absenceSearch");
  const rows = state.absences.filter((item) => role() !== "Funcionario" || item.userId === currentUser()?.id).filter((item) => search([userName(item.userId), item.type, item.status, item.reason], query));
  table("#absencesTable", rows, (item) => `
    <tr>
      <td>${esc(userName(item.userId))}</td>
      <td>${date(item.date)}</td>
      <td>${esc(item.type)}</td>
      <td><span class="status ${cls(item.status)}">${esc(item.status)}</span></td>
      <td><strong>${esc(item.compensateVacation === "Sim" ? "Compensada com férias" : "Sem compensação")}</strong><small>${esc(item.reason || "Sem motivo")}</small></td>
      <td><div class="row-actions">${role() !== "Funcionario" ? `<button class="row-action" data-edit-absence="${item.id}">Editar</button><button class="row-action approve" data-approve-absence="${item.id}">Validar</button><button class="row-action delete" data-reject-absence="${item.id}">Rejeitar</button>` : ""}</div></td>
    </tr>`);
}

function openDialog(mode, id = null, defaults = {}) {
  dialogMode = mode;
  editingId = id;
  const baseRecord = id ? collection(mode).find((item) => item.id === id) : { ...defaultRecord(mode), ...defaults };
  const record = mode === "client" ? clientFormRecord(baseRecord || {}) : baseRecord;
  qs("#dialogTitle").textContent = dialogTitle(mode, Boolean(id));
  qs("#dialogSubtitle").textContent = dialogSubtitle(mode);
  qs("#formAlert").textContent = "";
  qs("#formFields").innerHTML = forms[mode].map((field) => fieldHtml(field, record || {})).join("");
  qs("#recordDialog").showModal();
  setupDialogRules(mode);
}

function dialogTitle(mode, editing) {
  if (mode === "vacation") return editing ? "Editar pedido de férias" : "Novo pedido de férias";
  if (mode === "absence") return editing ? "Editar falta" : "Nova falta";
  return `${editing ? "Editar" : "Novo"} ${label(mode)}`;
}

function dialogSubtitle(mode) {
  if (mode === "client") return "Preencha os dados do cliente e da empresa na mesma ficha.";
  if (mode === "vacation") return "Escolha as datas. O sistema calcula os dias úteis e limita cada pedido a 15 dias.";
  if (mode === "absence") return "Registe a falta e indique se ela deve ser compensada com 1 dia de férias.";
  return "Preencha os dados principais.";
}

function fieldHtml([name, labelText, type, required], record) {
  const valueText = record[name] || "";
  const req = required ? "required" : "";
  if (type === "textarea") return `<label class="field full"><span>${labelText}</span><textarea name="${name}" ${req}>${esc(valueText)}</textarea></label>`;
  if (type === "company") return selectField(name, labelText, state.companies.map((item) => [item.id, item.name]), valueText, req);
  if (type === "client") return selectField(name, labelText, state.clients.map((item) => [item.id, item.name]), valueText, req);
  if (type === "user") {
    const users = role() === "Funcionario" && ["vacation", "absence"].includes(dialogMode) ? state.users.filter((item) => item.id === currentUser()?.id) : state.users;
    return selectField(name, labelText, users.map((item) => [item.id, item.name]), valueText, req);
  }
  if (type.startsWith("select:")) return selectField(name, labelText, type.replace("select:", "").split("|").map((item) => [item, item]), valueText, req);
  return `<label class="field"><span>${labelText}</span><input name="${name}" type="${type}" value="${esc(valueText)}" ${req}></label>`;
}

function selectField(name, labelText, options, valueText, req) {
  return `<label class="field"><span>${labelText}</span><select name="${name}" ${req}>${options.map(([valueOption, labelOption]) => `<option value="${esc(valueOption)}" ${valueText === valueOption ? "selected" : ""}>${esc(labelOption)}</option>`).join("")}</select></label>`;
}

function handleSubmit(event) {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  if (dialogMode === "client") {
    saveClientWithCompany(data);
    qs("#recordDialog").close();
    saveState();
    return;
  }
  if (dialogMode === "vacation") {
    const validation = validateVacation(data);
    if (!validation.ok) {
      qs("#formAlert").textContent = validation.message;
      return;
    }
    data.days = String(validation.days);
  }
  if (dialogMode === "absence") {
    const existingCompensation = editingId && state.vacations.some((item) => item.linkedAbsenceId === editingId);
    const usedForCompensation = vacationDaysUsed(data.userId) - (existingCompensation ? 1 : 0);
    if (data.compensateVacation === "Sim" && data.status !== "Rejeitado" && usedForCompensation + 1 > 30) {
      qs("#formAlert").textContent = "Não é possível compensar com férias porque o colaborador já atingiu o limite anual de 30 dias.";
      return;
    }
    saveAbsenceWithCompensation(data);
    qs("#recordDialog").close();
    saveState();
    return;
  }
  const target = collection(dialogMode);
  if (editingId) {
    const index = target.findIndex((item) => item.id === editingId);
    target[index] = { ...target[index], ...data };
  } else {
    target.push({ id: `${dialogMode}-${Date.now()}`, ...data });
  }
  qs("#recordDialog").close();
  saveState();
}

function clientFormRecord(client) {
  const company = companyForClient(client);
  return {
    ...client,
    companyName: company.name || "",
    vat: company.vat || "",
    city: company.city || "",
    sector: company.sector || "",
    address: company.address || ""
  };
}

function saveClientWithCompany(data) {
  const companyData = {
    name: data.companyName || data.name,
    vat: data.vat || "",
    email: data.email || "",
    phone: data.phone || "",
    city: data.city || "",
    sector: data.sector || "",
    address: data.address || "",
    notes: data.notes || ""
  };
  const existingClient = editingId ? state.clients.find((client) => client.id === editingId) : null;
  const companyId = existingClient?.companyId || `empresa-${Date.now()}`;
  const companyIndex = state.companies.findIndex((company) => company.id === companyId);
  if (companyIndex >= 0) state.companies[companyIndex] = { ...state.companies[companyIndex], ...companyData, id: companyId };
  else state.companies.push({ id: companyId, ...companyData });

  const clientData = {
    name: data.name,
    companyId,
    email: data.email,
    password: data.password,
    phone: data.phone,
    status: data.status,
    owner: data.owner,
    role: data.role,
    notes: data.notes
  };
  if (existingClient) Object.assign(existingClient, clientData);
  else state.clients.push({ id: `client-${Date.now()}`, ...clientData });
}

function setupDialogRules(mode) {
  if (mode !== "vacation") return;
  const form = qs("#recordForm");
  const start = form.elements.startDate;
  const end = form.elements.endDate;
  const days = form.elements.days;
  const user = form.elements.userId;
  days.readOnly = true;
  days.required = false;
  days.parentElement.insertAdjacentHTML("beforeend", `<small class="field-hint" id="vacationDayHint"></small>`);
  const update = () => updateVacationCalculation();
  [start, end, user].forEach((field) => field?.addEventListener("change", update));
  update();
}

function updateVacationCalculation() {
  const form = qs("#recordForm");
  if (dialogMode !== "vacation" || !form) return;
  const start = form.elements.startDate;
  const end = form.elements.endDate;
  const days = form.elements.days;
  const hint = qs("#vacationDayHint");
  if (!start.value) {
    days.value = "";
    if (hint) hint.textContent = "Preencha a data inicial para calcular os dias.";
    return;
  }
  end.min = start.value;
  end.max = addDays(start.value, 14);
  if (!end.value || end.value < start.value) end.value = start.value;
  if (end.value > end.max) end.value = end.max;
  let total = businessDays(start.value, end.value);
  while (total > 15) {
    end.value = addDays(end.value, -1);
    total = businessDays(start.value, end.value);
  }
  days.value = total || "";
  const used = vacationDaysUsed(form.elements.userId.value, editingId);
  const remaining = Math.max(30 - used - total, 0);
  if (hint) hint.textContent = `Total deste pedido: ${total} dias úteis. Já usados/pendentes: ${used}/30. Restam após este pedido: ${remaining}.`;
}

function validateVacation(data) {
  const days = businessDays(data.startDate, data.endDate);
  if (!data.startDate || !data.endDate) return { ok: false, message: "Preencha a data inicial e a data final." };
  if (new Date(data.endDate) < new Date(data.startDate)) return { ok: false, message: "A data final não pode ser anterior à data inicial." };
  if (data.endDate > addDays(data.startDate, 14)) return { ok: false, message: "A data final pode ir apenas até 15 dias corridos a partir da data inicial." };
  if (days < 1) return { ok: false, message: "O período precisa ter pelo menos 1 dia útil." };
  if (days > 15) return { ok: false, message: "Cada pedido de férias pode ter no máximo 15 dias úteis a partir da data inicial." };
  const used = vacationDaysUsed(data.userId, editingId);
  if (used + days > 30) return { ok: false, message: `Este colaborador já tem ${used} dias usados/pendentes. O limite anual é 30 dias.` };
  return { ok: true, days };
}

function vacationDaysUsed(userId, ignoreId = null) {
  return state.vacations
    .filter((item) => item.userId === userId && item.id !== ignoreId && item.status !== "Rejeitado")
    .reduce((total, item) => total + Number(item.days || 0), 0);
}

function businessDays(startValue, endValue) {
  if (!startValue || !endValue) return 0;
  const start = new Date(`${startValue}T00:00:00`);
  const end = new Date(`${endValue}T00:00:00`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end < start) return 0;
  let total = 0;
  const current = new Date(start);
  while (current <= end) {
    const day = current.getDay();
    if (day !== 0 && day !== 6) total += 1;
    current.setDate(current.getDate() + 1);
  }
  return total;
}

function addDays(valueText, amount) {
  const dateValue = new Date(`${valueText}T00:00:00`);
  dateValue.setDate(dateValue.getDate() + amount);
  const month = String(dateValue.getMonth() + 1).padStart(2, "0");
  const day = String(dateValue.getDate()).padStart(2, "0");
  return `${dateValue.getFullYear()}-${month}-${day}`;
}

function saveAbsenceWithCompensation(data) {
  const target = state.absences;
  const id = editingId || `absence-${Date.now()}`;
  const record = { id, ...data };
  const index = target.findIndex((item) => item.id === id);
  if (index >= 0) target[index] = { ...target[index], ...record };
  else target.push(record);

  syncAbsenceCompensation(record);
}

function syncAbsenceCompensation(absence) {
  state.vacations = state.vacations.filter((item) => item.linkedAbsenceId !== absence.id);
  if (absence.compensateVacation !== "Sim" || absence.status === "Rejeitado") return;
  const status = absence.status === "Aprovado" ? "Aprovado" : "Pendente";
  state.vacations.push({
    id: `vac-comp-${absence.id}`,
    userId: absence.userId,
    startDate: absence.date,
    endDate: absence.date,
    days: "1",
    origin: "Compensação de falta",
    status,
    notes: `Compensação da falta de ${date(absence.date)} para evitar desconto.`,
    decidedBy: status === "Aprovado" ? currentUser()?.name || "Admin/RH" : "",
    linkedAbsenceId: absence.id
  });
}

function collection(mode) {
  return { client: state.clients, company: state.companies, order: state.orders, user: state.users, vacation: state.vacations, absence: state.absences }[mode];
}

function defaultRecord(mode) {
  if (mode === "order") return { clientId: state.clients[0]?.id, status: "Recebido", progress: "0" };
  if (mode === "vacation") return { userId: currentUser()?.id || "user-funcionario", origin: role() === "Funcionario" ? "Funcionario" : "Admin/RH", status: role() === "Funcionario" ? "Pendente" : "Aprovado" };
  if (mode === "absence") return { userId: currentUser()?.id || "user-funcionario", type: "Justificada", compensateVacation: "Não", status: "Pendente" };
  if (mode === "user") return { role: "Funcionario", status: "Ativo" };
  if (mode === "client") return { companyName: "", status: "Ativo", password: "cliente123" };
  return {};
}

function label(mode) {
  return { client: "cliente / empresa", company: "empresa", order: "encomenda", user: "colaborador", vacation: "férias", absence: "falta" }[mode];
}

function deleteRecord(mode, id) {
  if (!confirm(`Apagar ${label(mode)}?`)) return;
  const key = { client: "clients", company: "companies", order: "orders", user: "users", vacation: "vacations", absence: "absences" }[mode];
  state[key] = state[key].filter((item) => item.id !== id);
  if (mode === "absence") state.vacations = state.vacations.filter((item) => item.linkedAbsenceId !== id);
  saveState();
}

function approve(mode, id, status) {
  const item = collection(mode).find((record) => record.id === id);
  if (!item) return;
  item.status = status;
  item.decidedBy = currentUser()?.name || "Admin";
  if (mode === "absence") syncAbsenceCompensation(item);
  saveState();
}

function openSchedule(orderId) {
  const order = state.orders.find((item) => item.id === orderId);
  if (!order) return;
  const readonly = isClient();
  qs("#scheduleDialogTitle").textContent = `Cronograma - ${order.reference}`;
  qs("#scheduleDialogMode").textContent = readonly ? "Visualizacao do cliente" : "Edicao do admin";
  qs("#scheduleBody").innerHTML = scheduleHtml(order, readonly);
  qs("#scheduleDialog").showModal();
}

function scheduleHtml(order, readonly) {
  const data = order.schedule || {};
  const disabled = readonly ? "disabled" : "";
  const value = (key) => esc(data[key] ?? "");
  const checked = (key) => data[key] ? "checked" : "";
  const rows = scheduleOperations.map((op, row) => {
    const weeks = Array.from({ length: 16 }, (_, index) => {
      const key = `r${row}_w${index + 1}`;
      return `<td class="week-cell"><input data-schedule="${key}" type="checkbox" ${checked(key)} ${disabled}></td>`;
    }).join("");
    const evol = [25, 50, 75, 100].map((percent) => {
      const key = `r${row}_e${percent}`;
      return `<td class="evol"><input data-schedule="${key}" name="evol${row}" type="radio" value="${percent}" ${checked(key)} ${disabled}></td>`;
    }).join("");
    return `<tr><td class="op-pt">${esc(op[0])}</td><td class="op-en">${esc(op[1])}</td><td class="resp">${esc(op[2])}</td>${weeks}${evol}</tr>`;
  }).join("");

  return `
    <div class="schedule-page" data-order-id="${order.id}" data-readonly="${readonly}">
      <header class="schedule-header">
        <div><div class="schedule-logo"><span>D</span> DUOMOLD</div><div class="schedule-subtitle">Mold Infinity</div></div>
        <div><div class="schedule-title">Cronograma Construcao de Molde<small>(Progress Report / Tool identification and property)</small></div><div class="page-no">Pagina 1 de 1</div></div>
      </header>

      <section class="schedule-top-grid">
        <div><label>N. Molde:<small>Mold number:</small><input data-schedule="moldNumber" value="${value("moldNumber")}" ${disabled}></label></div>
        <div><label>No Molde Cliente:<small>Customer mold number:</small><input data-schedule="customerMoldNumber" value="${value("customerMoldNumber")}" ${disabled}></label></div>
        <div><label>Week:<input data-schedule="week" value="${value("week")}" ${disabled}></label></div>
        <div><label>OS:<input value="${esc(order.reference)}" disabled></label></div>
      </section>

      <table class="schedule-table">
        <colgroup><col style="width:19%"><col style="width:19%"><col style="width:5.3%"><col span="16" style="width:2.85%"><col span="4" style="width:3.8%"></colgroup>
        <thead>
          <tr><th colspan="2" rowspan="2">Operacoes / Operations</th><th rowspan="2">Resp.</th><th colspan="16">Semana / Week</th><th colspan="4">Evolucao (%)</th></tr>
          <tr>${Array.from({ length: 16 }, () => "<th></th>").join("")}${[25, 50, 75, 100].map((item) => `<th>${item}</th>`).join("")}</tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>

      <div class="schedule-section-title">Outras caracteristicas:<small>Other characteristics:</small></div>
      <div class="schedule-chars">
        <div>Ref. Peca:<small>Part reference:</small><input data-schedule="partReference" value="${value("partReference")}" ${disabled}></div>
        <div>Peso Moldacao (g):<small>Injection weight (g):</small><input data-schedule="injectionWeight" value="${value("injectionWeight")}" ${disabled}></div>
        <div>N. cavidades:<small>Number of cavities:</small><input data-schedule="cavities" value="${value("cavities")}" ${disabled}></div>
        <div>Peso Molde:<small>Tool weight:</small><input data-schedule="toolWeight" value="${value("toolWeight")}" ${disabled}></div>
        <div>Dimensoes:<small>Dimensions:</small><input data-schedule="dimensions" value="${value("dimensions")}" ${disabled}></div>
        <div>Tempo de vida (ciclos):<small>Life time:</small><input data-schedule="lifetime" value="${value("lifetime")}" ${disabled}></div>
      </div>
      <div class="schedule-remarks"><div class="remarks-title">Observacoes:<small>Remarks:</small></div><textarea data-schedule="remarks" ${disabled}>${value("remarks")}</textarea></div>

      <div class="signatures">
        <div class="sig"><div class="sig-title">DUOMOLD, Lda.</div><div class="line"></div><div class="date-row">Data: <input data-schedule="duoDay" value="${value("duoDay")}" ${disabled}> / <input data-schedule="duoMonth" value="${value("duoMonth")}" ${disabled}> / <input data-schedule="duoYear" value="${value("duoYear")}" ${disabled}></div></div>
        <div class="sig"><div class="sig-title">Cliente</div><div class="line"></div><div class="date-row">Data: <input data-schedule="clientDay" value="${value("clientDay")}" ${disabled}> / <input data-schedule="clientMonth" value="${value("clientMonth")}" ${disabled}> / <input data-schedule="clientYear" value="${value("clientYear")}" ${disabled}></div></div>
      </div>
      <footer class="schedule-footer">MOD.55.01</footer>
    </div>`;
}

function saveSchedule() {
  const page = qs(".schedule-page");
  if (!page || page.dataset.readonly === "true") return;
  const order = state.orders.find((item) => item.id === page.dataset.orderId);
  if (!order) return;
  order.schedule = {};
  qsa("[data-schedule]").forEach((field) => {
    const key = field.dataset.schedule;
    order.schedule[key] = field.type === "checkbox" || field.type === "radio" ? field.checked : field.value;
  });
  localStorage.setItem(storageKey, JSON.stringify(state));
}

function exportSchedule() {
  const page = qs(".schedule-page");
  if (!page) return;
  const order = state.orders.find((item) => item.id === page.dataset.orderId);
  const blob = new Blob([JSON.stringify(order?.schedule || {}, null, 2)], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `cronograma-${order?.reference || "molde"}.json`;
  link.click();
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function defaultPlanning(order) {
  return {
    projeto: order.reference || "DMxxx",
    cliente: clientName(order.clientId),
    molde: "",
    data: today(),
    observacoes: "",
    campos: [],
    linhas: structuredClone(planningBase)
  };
}

function planningFor(order) {
  if (!order.planning) order.planning = defaultPlanning(order);
  if (!Array.isArray(order.planning.campos)) order.planning.campos = [];
  if (!Array.isArray(order.planning.linhas) || !order.planning.linhas.length) order.planning.linhas = structuredClone(planningBase);
  order.planning.linhas.forEach((line, index) => {
    if (!line.id) line.id = index + 1;
    if (!Array.isArray(line.extras)) line.extras = [];
    while (line.extras.length < order.planning.campos.length) line.extras.push("");
  });
  return order.planning;
}

function openPlanning(orderId) {
  const order = state.orders.find((item) => item.id === orderId);
  if (!order) return;
  const readonly = isClient();
  qs("#planningDialogTitle").textContent = `Planeamento - ${order.reference}`;
  qs("#planningDialogMode").textContent = readonly ? "Visualizacao do cliente" : "Edicao do admin";
  qs("#planningBody").innerHTML = planningHtml(order, readonly);
  ["#renumberPlanningButton", "#addPlanningTaskButton", "#addPlanningGroupButton", "#addPlanningFieldButton", "#clearPlanningButton"].forEach((selector) => {
    qs(selector).hidden = readonly;
  });
  qs("#planningDialog").showModal();
}

function planningHtml(order, readonly) {
  const data = planningFor(order);
  const disabled = readonly ? "disabled" : "";
  const readonlyClass = readonly ? " readonly" : "";
  const field = (key) => esc(data[key] ?? "");
  const extraHeaders = data.campos.map((campo, index) => `
    <th class="planning-extra">${esc(campo.nome)}
      ${readonly ? "" : `<button class="planning-mini red" data-planning-delete-field="${index}" type="button">X</button>`}
    </th>`).join("");
  const rows = data.linhas.map((line, index) => planningRowHtml(line, index, data.campos, disabled, readonly)).join("");

  return `
    <div class="planning-page${readonlyClass}" data-order-id="${order.id}" data-readonly="${readonly}">
      <header class="planning-header">
        <div>
          <h2>Planeamento do Molde - MOD.54.01</h2>
          <p>Colunas: ID - Nome da Tarefa - Duracao - Inicio - Conclusao - Status</p>
        </div>
      </header>

      <section class="planning-card">
        <div class="planning-grid">
          <label>Projecto<input data-planning-field="projeto" value="${field("projeto")}" ${disabled}></label>
          <label>Cliente<input data-planning-field="cliente" value="${field("cliente")}" ${disabled}></label>
          <label>N. Molde<input data-planning-field="molde" value="${field("molde")}" ${disabled}></label>
          <label>Data<input data-planning-field="data" type="date" value="${field("data")}" ${disabled}></label>
        </div>
        ${readonly ? `<p class="planning-note">Visualizacao do cliente. A edicao fica disponivel apenas para Admin.</p>` : `<p class="planning-note">Os campos criados aparecem como colunas dentro da planilha.</p>`}
      </section>

      <section class="planning-table-box">
        <table class="planning-table">
          <thead>
            <tr>
              <th class="planning-id">ID</th>
              <th class="planning-name">Nome da Tarefa</th>
              <th class="planning-duration">Duracao</th>
              <th class="planning-date">Inicio</th>
              <th class="planning-date">Conclusao</th>
              <th class="planning-status">Status</th>
              ${extraHeaders}
              ${readonly ? "" : `<th class="planning-actions-col">Acoes</th>`}
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </section>

      <section class="planning-card">
        <label>Observacoes<textarea data-planning-field="observacoes" ${disabled}>${field("observacoes")}</textarea></label>
      </section>
      <footer class="planning-footer">MOD.54.01</footer>
    </div>`;
}

function planningRowHtml(line, index, fields, disabled, readonly) {
  const options = planningStatusOptions.map((option) => `<option value="${esc(option)}" ${option === line.status ? "selected" : ""}>${esc(option)}</option>`).join("");
  const extras = fields.map((_, extraIndex) => `<td><input data-planning-row="${index}" data-planning-extra="${extraIndex}" value="${esc(line.extras?.[extraIndex] || "")}" ${disabled}></td>`).join("");
  return `
    <tr class="${planningStatusClass(line.status)}">
      <td><input data-planning-row="${index}" data-planning-prop="id" value="${esc(line.id)}" ${disabled}></td>
      <td><input data-planning-row="${index}" data-planning-prop="nome" value="${esc(line.nome)}" ${disabled}></td>
      <td><input data-planning-row="${index}" data-planning-prop="duracao" value="${esc(line.duracao)}" placeholder="Ex.: 5 dias" ${disabled}></td>
      <td><input data-planning-row="${index}" data-planning-prop="inicio" type="date" value="${esc(line.inicio)}" ${disabled}></td>
      <td><input data-planning-row="${index}" data-planning-prop="conclusao" type="date" value="${esc(line.conclusao)}" ${disabled}></td>
      <td><select data-planning-row="${index}" data-planning-prop="status" ${disabled}>${options}</select></td>
      ${extras}
      ${readonly ? "" : `<td><button class="planning-mini red" data-planning-delete-row="${index}" type="button">X</button></td>`}
    </tr>`;
}

function planningStatusClass(status) {
  const valueText = String(status || "").toLowerCase();
  if (valueText.includes("inativ")) return "planning-inactive";
  if (valueText.includes("sumario") || valueText.includes("resumo")) return "planning-summary";
  if (valueText.includes("projeto")) return "planning-project";
  return "";
}

function activePlanning() {
  const page = qs(".planning-page");
  if (!page) return {};
  const order = state.orders.find((item) => item.id === page.dataset.orderId);
  return { page, order, data: order ? planningFor(order) : null, readonly: page.dataset.readonly === "true" };
}

function savePlanningField(target) {
  const { data, readonly } = activePlanning();
  if (!data || readonly) return;
  const topField = target.dataset.planningField;
  if (topField) data[topField] = target.value;
  const rowIndex = target.dataset.planningRow;
  const prop = target.dataset.planningProp;
  if (rowIndex !== undefined && prop) data.linhas[rowIndex][prop] = target.value;
  const extraIndex = target.dataset.planningExtra;
  if (rowIndex !== undefined && extraIndex !== undefined) data.linhas[rowIndex].extras[extraIndex] = target.value;
  localStorage.setItem(storageKey, JSON.stringify(state));
}

function refreshPlanning() {
  const { order, readonly } = activePlanning();
  if (!order) return;
  qs("#planningBody").innerHTML = planningHtml(order, readonly);
  localStorage.setItem(storageKey, JSON.stringify(state));
}

function addPlanningLine(type = "tarefa") {
  const { data, readonly } = activePlanning();
  if (!data || readonly) return;
  const name = prompt(type === "grupo" ? "Nome do novo grupo" : "Nome da nova tarefa");
  if (!name) return;
  data.linhas.push({
    id: data.linhas.length + 1,
    nome: name,
    duracao: "",
    inicio: "",
    conclusao: "",
    status: type === "grupo" ? "Sumario" : "Tarefa",
    extras: data.campos.map(() => "")
  });
  refreshPlanning();
}

function addPlanningField() {
  const { data, readonly } = activePlanning();
  if (!data || readonly) return;
  const name = prompt("Nome do novo campo");
  if (!name) return;
  const initialValue = prompt("Valor inicial nas linhas", "") || "";
  data.campos.push({ nome: name });
  data.linhas.forEach((line) => line.extras.push(initialValue));
  refreshPlanning();
}

function renumberPlanning() {
  const { data, readonly } = activePlanning();
  if (!data || readonly) return;
  data.linhas.forEach((line, index) => line.id = index + 1);
  refreshPlanning();
}

function exportPlanning() {
  const { order } = activePlanning();
  if (!order) return;
  const blob = new Blob([JSON.stringify(planningFor(order), null, 2)], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `planeamento-${order.reference || "molde"}.json`;
  link.click();
}

function resetPlanning() {
  const { order, readonly } = activePlanning();
  if (!order || readonly || !confirm("Limpar tudo e voltar ao modelo inicial?")) return;
  order.planning = defaultPlanning(order);
  refreshPlanning();
}

function compact(selector, items, mapper) {
  const element = qs(selector);
  if (!element) return;
  if (!items.length) {
    element.innerHTML = `<div class="empty-state">Sem registos.</div>`;
    return;
  }
  element.innerHTML = items.slice(0, 5).map((item) => {
    const view = mapper(item);
    return `<article class="compact-item"><div><strong>${esc(view.title)}</strong><small>${esc(view.meta)}</small></div><span class="status">${esc(view.badge)}</span></article>`;
  }).join("");
}

function table(selector, rows, mapper) {
  const tbody = qs(selector);
  if (!tbody) return;
  tbody.innerHTML = rows.length ? rows.map(mapper).join("") : qs("#emptyStateTemplate").innerHTML;
}

function text(selector, valueText) {
  const element = qs(selector);
  if (element) element.textContent = valueText;
}

function value(selector) {
  return qs(selector)?.value.trim().toLowerCase() || "";
}

function search(parts, query) {
  return parts.join(" ").toLowerCase().includes(query);
}

function sum(items) {
  return items.reduce((total, item) => total + Number(item.days || 0), 0);
}

function companyName(id) {
  return state.companies.find((item) => item.id === id)?.name || "Sem empresa";
}

function companyForClient(client) {
  return state.companies.find((item) => item.id === client?.companyId) || {};
}

function clientName(id) {
  return state.clients.find((item) => item.id === id)?.name || "Sem cliente";
}

function userName(id) {
  return state.users.find((item) => item.id === id)?.name || "Sem colaborador";
}

function date(valueText) {
  if (!valueText) return "Sem data";
  return new Intl.DateTimeFormat("pt-PT").format(new Date(`${valueText}T00:00:00`));
}

function cls(valueText) {
  return String(valueText || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[\/\s]+/g, "-");
}

function esc(valueText) {
  return String(valueText ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
}

qsa(".nav-item").forEach((button) => button.addEventListener("click", () => setView(button.dataset.view)));
qsa("[data-view-jump]").forEach((button) => button.addEventListener("click", () => setView(button.dataset.viewJump)));
qs("#demoAccountSelect").addEventListener("change", (event) => {
  state.activeAccount = event.target.value;
  saveState();
  setView(defaultView());
});
qs("#newRecordButton").addEventListener("click", () => openDialog(modeFromView()));
qs("#addClientButton").addEventListener("click", () => openDialog("client"));
qs("#addCompanyButton").addEventListener("click", () => openDialog("company"));
qs("#addOrderButton").addEventListener("click", () => openDialog("order"));
qs("#addUserButton").addEventListener("click", () => openDialog("user"));
qs("#addVacationButton").addEventListener("click", () => openDialog("vacation"));
qs("#addAbsenceButton").addEventListener("click", () => openDialog("absence"));
qs("#employeeVacationShortcut").addEventListener("click", () => openDialog("vacation"));
qs("#recordForm").addEventListener("submit", handleSubmit);
qs("#closeDialogButton").addEventListener("click", () => qs("#recordDialog").close());
qs("#cancelDialogButton").addEventListener("click", () => qs("#recordDialog").close());
qs("#exportButton").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "duomold-demo.json";
  link.click();
});
["client", "company", "order", "user", "vacation", "absence"].forEach((name) => qs(`#${name}Search`)?.addEventListener("input", render));

document.addEventListener("click", (event) => {
  const target = event.target;
  const action = [
    ["edit-client", "client", openDialog], ["delete-client", "client", deleteRecord],
    ["edit-company", "company", openDialog], ["delete-company", "company", deleteRecord],
    ["edit-order", "order", openDialog], ["delete-order", "order", deleteRecord],
    ["edit-user", "user", openDialog], ["delete-user", "user", deleteRecord],
    ["edit-vacation", "vacation", openDialog], ["edit-absence", "absence", openDialog]
  ].find(([key]) => target.closest(`[data-${key}]`));
  if (action) {
    const [key, mode, fn] = action;
    fn(mode, target.closest(`[data-${key}]`).dataset[toDatasetKey(key)]);
  }
  if (target.closest("[data-new-client-order]")) openDialog("order", null, { clientId: target.closest("[data-new-client-order]").dataset.newClientOrder });
  if (target.closest("[data-schedule-order]")) openSchedule(target.closest("[data-schedule-order]").dataset.scheduleOrder);
  if (target.closest("[data-planning-order]")) openPlanning(target.closest("[data-planning-order]").dataset.planningOrder);
  if (target.closest("[data-planning-delete-row]")) {
    const { data, readonly } = activePlanning();
    if (data && !readonly && confirm("Eliminar esta tarefa?")) {
      data.linhas.splice(Number(target.closest("[data-planning-delete-row]").dataset.planningDeleteRow), 1);
      refreshPlanning();
    }
  }
  if (target.closest("[data-planning-delete-field]")) {
    const { data, readonly } = activePlanning();
    if (data && !readonly && confirm("Eliminar este campo?")) {
      const index = Number(target.closest("[data-planning-delete-field]").dataset.planningDeleteField);
      data.campos.splice(index, 1);
      data.linhas.forEach((line) => line.extras.splice(index, 1));
      refreshPlanning();
    }
  }
  if (target.closest("[data-approve-vacation]")) approve("vacation", target.closest("[data-approve-vacation]").dataset.approveVacation, "Aprovado");
  if (target.closest("[data-reject-vacation]")) approve("vacation", target.closest("[data-reject-vacation]").dataset.rejectVacation, "Rejeitado");
  if (target.closest("[data-approve-absence]")) approve("absence", target.closest("[data-approve-absence]").dataset.approveAbsence, "Aprovado");
  if (target.closest("[data-reject-absence]")) approve("absence", target.closest("[data-reject-absence]").dataset.rejectAbsence, "Rejeitado");
});

document.addEventListener("input", (event) => {
  if (event.target.closest("#scheduleDialog")) saveSchedule();
  if (event.target.closest("#planningDialog")) savePlanningField(event.target);
});

document.addEventListener("change", (event) => {
  if (event.target.closest("#scheduleDialog")) saveSchedule();
  if (event.target.closest("#planningDialog")) savePlanningField(event.target);
});

qs("#closeScheduleButton").addEventListener("click", () => qs("#scheduleDialog").close());
qs("#printScheduleButton").addEventListener("click", () => printDocument("schedule"));
qs("#exportScheduleButton").addEventListener("click", () => printDocument("schedule"));
qs("#closePlanningButton").addEventListener("click", () => qs("#planningDialog").close());
qs("#printPlanningButton").addEventListener("click", () => printDocument("planning"));
qs("#exportPlanningButton").addEventListener("click", () => printDocument("planning"));
qs("#renumberPlanningButton").addEventListener("click", renumberPlanning);
qs("#addPlanningTaskButton").addEventListener("click", () => addPlanningLine("tarefa"));
qs("#addPlanningGroupButton").addEventListener("click", () => addPlanningLine("grupo"));
qs("#addPlanningFieldButton").addEventListener("click", addPlanningField);
qs("#clearPlanningButton").addEventListener("click", resetPlanning);

function printDocument(type) {
  document.body.classList.remove("printing-schedule", "printing-planning");
  document.body.classList.add(`printing-${type}`);
  window.print();
}

window.addEventListener("beforeprint", () => {
  if (!document.body.classList.contains("printing-schedule") && !document.body.classList.contains("printing-planning")) {
    if (qs("#planningDialog")?.open) document.body.classList.add("printing-planning");
    if (qs("#scheduleDialog")?.open) document.body.classList.add("printing-schedule");
  }
});

window.addEventListener("afterprint", () => {
  document.body.classList.remove("printing-schedule", "printing-planning");
});

function toDatasetKey(key) {
  return key.replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
}

setView(defaultView());
render();
